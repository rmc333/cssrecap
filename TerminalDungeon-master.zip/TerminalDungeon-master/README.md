# terminal_dungeon

Practice your terminal commands within the terminal dungeon! cd in and out of folders to nagivate your way through three daunting levels.

Watch out for dead ends and monsters!

Commands you will use:
<br>
<strong>cd</strong> - change directory
<br>
<strong>cd..</strong> - go back a directory
<br>
<strong>dir (Windows) - ls (Mac)</strong> - see what's inside the folder you're currently in


<strong><i>Be sure to traverse the dungeon in the command prompt itself. No cheating in VSCode!</i></strong>

<strong>Tip: <i>Hitting tab after starting to type will autofill.</i></strong>
